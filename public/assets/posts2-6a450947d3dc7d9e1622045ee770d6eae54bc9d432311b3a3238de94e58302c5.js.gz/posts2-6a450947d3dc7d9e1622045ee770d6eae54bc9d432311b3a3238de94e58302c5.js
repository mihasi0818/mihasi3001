function formSwitch() {
    const selectedRadioGroup = document.getElementsByName('maker1');
    
    if (selectedRadioGroup[0].checked) {
        // 好きな食べ物が選択されたら下記を実行します
        document.getElementById('tankList').style.display = "";
        document.getElementById('fightList').style.display = "none";
        document.getElementById('mageList').style.display = "none";
        document.getElementById('asasinList').style.display = "none";
        document.getElementById('hanterList').style.display = "none";
        document.getElementById('supportList').style.display = "none";
    } else if (selectedRadioGroup[1].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList').style.display = "none";
        document.getElementById('fightList').style.display = "";
        document.getElementById('mageList').style.display = "none";
        document.getElementById('asasinList').style.display = "none";
        document.getElementById('hanterList').style.display = "none";
        document.getElementById('supportList').style.display = "none";
    } else if (selectedRadioGroup[2].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList').style.display = "none";
        document.getElementById('fightList').style.display = "none";
        document.getElementById('mageList').style.display = "";
        document.getElementById('asasinList').style.display = "none";
        document.getElementById('hanterList').style.display = "none";
        document.getElementById('supportList').style.display = "none";
    } else if (selectedRadioGroup[3].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList').style.display = "none";
        document.getElementById('fightList').style.display = "none";
        document.getElementById('mageList').style.display = "none";
        document.getElementById('asasinList').style.display = "";
        document.getElementById('hanterList').style.display = "none";
        document.getElementById('supportList').style.display = "none";
    } else if (selectedRadioGroup[4].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList').style.display = "none";
        document.getElementById('fightList').style.display = "none";
        document.getElementById('mageList').style.display = "none";
        document.getElementById('asasinList').style.display = "none";
        document.getElementById('hanterList').style.display = "";
        document.getElementById('supportList').style.display = "none";  
    } else if (selectedRadioGroup[5].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList').style.display = "none";
        document.getElementById('fightList').style.display = "none";
        document.getElementById('mageList').style.display = "none";
        document.getElementById('asasinList').style.display = "none";
        document.getElementById('hanterList').style.display = "none";
        document.getElementById('supportList').style.display = "";  
    
    
    } else {
        document.getElementById('tankList').style.display = "none";
        document.getElementById('fightList').style.display = "none";
        document.getElementById('mageList').style.display = "none";
        document.getElementById('asasinList').style.display = "none";
        document.getElementById('hanterList').style.display = "none";
        document.getElementById('supportList').style.display = "none";  
    }
}

window.addEventListener('load',formSwitch);

function formSwitch2() {
    const selectedRadioGroup = document.getElementsByName('maker2');
    
    if (selectedRadioGroup[0].checked) {
        // 好きな食べ物が選択されたら下記を実行します
        document.getElementById('tankList2').style.display = "";
        document.getElementById('fightList2').style.display = "none";
        document.getElementById('mageList2').style.display = "none";
        document.getElementById('asasinList2').style.display = "none";
        document.getElementById('hanterList2').style.display = "none";
        document.getElementById('supportList2').style.display = "none";
    } else if (selectedRadioGroup[1].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList2').style.display = "none";
        document.getElementById('fightList2').style.display = "";
        document.getElementById('mageList2').style.display = "none";
        document.getElementById('asasinList2').style.display = "none";
        document.getElementById('hanterList2').style.display = "none";
        document.getElementById('supportList2').style.display = "none";
    } else if (selectedRadioGroup[2].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList2').style.display = "none";
        document.getElementById('fightList2').style.display = "none";
        document.getElementById('mageList2').style.display = "";
        document.getElementById('asasinList2').style.display = "none";
        document.getElementById('hanterList2').style.display = "none";
        document.getElementById('supportList2').style.display = "none";
    } else if (selectedRadioGroup[3].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList2').style.display = "none";
        document.getElementById('fightList2').style.display = "none";
        document.getElementById('mageList2').style.display = "none";
        document.getElementById('asasinList2').style.display = "";
        document.getElementById('hanterList2').style.display = "none";
        document.getElementById('supportList2').style.display = "none";
    } else if (selectedRadioGroup[4].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList2').style.display = "none";
        document.getElementById('fightList2').style.display = "none";
        document.getElementById('mageList2').style.display = "none";
        document.getElementById('asasinList2').style.display = "none";
        document.getElementById('hanterList2').style.display = "";
        document.getElementById('supportList2').style.display = "none";  
    } else if (selectedRadioGroup[5].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList2').style.display = "none";
        document.getElementById('fightList2').style.display = "none";
        document.getElementById('mageList2').style.display = "none";
        document.getElementById('asasinList2').style.display = "none";
        document.getElementById('hanterList2').style.display = "none";
        document.getElementById('supportList2').style.display = "";  
    
    
    } else {
        document.getElementById('tankList2').style.display = "none";
        document.getElementById('fightList2').style.display = "none";
        document.getElementById('mageList2').style.display = "none";
        document.getElementById('asasinList2').style.display = "none";
        document.getElementById('hanterList2').style.display = "none";
        document.getElementById('supportList2').style.display = "none";  
    }
}

window.addEventListener('load',formSwitch2);

function formSwitch22() {
    const selectedRadioGroup = document.getElementsByName('maker22');
    
    if (selectedRadioGroup[0].checked) {
        // 好きな食べ物が選択されたら下記を実行します
        document.getElementById('tankList22').style.display = "";
        document.getElementById('fightList22').style.display = "none";
        document.getElementById('mageList22').style.display = "none";
        document.getElementById('asasinList22').style.display = "none";
        document.getElementById('hanterList22').style.display = "none";
        document.getElementById('supportList22').style.display = "none";
    } else if (selectedRadioGroup[1].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList22').style.display = "none";
        document.getElementById('fightList22').style.display = "";
        document.getElementById('mageList22').style.display = "none";
        document.getElementById('asasinList22').style.display = "none";
        document.getElementById('hanterList22').style.display = "none";
        document.getElementById('supportList22').style.display = "none";
    } else if (selectedRadioGroup[2].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList22').style.display = "none";
        document.getElementById('fightList22').style.display = "none";
        document.getElementById('mageList22').style.display = "";
        document.getElementById('asasinList22').style.display = "none";
        document.getElementById('hanterList22').style.display = "none";
        document.getElementById('supportList22').style.display = "none";
    } else if (selectedRadioGroup[3].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList22').style.display = "none";
        document.getElementById('fightList22').style.display = "none";
        document.getElementById('mageList22').style.display = "none";
        document.getElementById('asasinList22').style.display = "";
        document.getElementById('hanterList22').style.display = "none";
        document.getElementById('supportList22').style.display = "none";
    } else if (selectedRadioGroup[4].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList22').style.display = "none";
        document.getElementById('fightList22').style.display = "none";
        document.getElementById('mageList22').style.display = "none";
        document.getElementById('asasinList22').style.display = "none";
        document.getElementById('hanterList22').style.display = "";
        document.getElementById('supportList22').style.display = "none";  
    } else if (selectedRadioGroup[5].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList22').style.display = "none";
        document.getElementById('fightList22').style.display = "none";
        document.getElementById('mageList22').style.display = "none";
        document.getElementById('asasinList22').style.display = "none";
        document.getElementById('hanterList22').style.display = "none";
        document.getElementById('supportList22').style.display = "";  
    
    
    } else {
        document.getElementById('tankList22').style.display = "none";
        document.getElementById('fightList22').style.display = "none";
        document.getElementById('mageList22').style.display = "none";
        document.getElementById('asasinList22').style.display = "none";
        document.getElementById('hanterList22').style.display = "none";
        document.getElementById('supportList22').style.display = "none";  
    }
}

window.addEventListener('load',formSwitch22);


function formSwitch23() {
    const selectedRadioGroup = document.getElementsByName('maker23');
    
    if (selectedRadioGroup[0].checked) {
        // 好きな食べ物が選択されたら下記を実行します
        document.getElementById('tankList23').style.display = "";
        document.getElementById('fightList23').style.display = "none";
        document.getElementById('mageList23').style.display = "none";
        document.getElementById('asasinList23').style.display = "none";
        document.getElementById('hanterList23').style.display = "none";
        document.getElementById('supportList23').style.display = "none";
    } else if (selectedRadioGroup[1].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList23').style.display = "none";
        document.getElementById('fightList23').style.display = "";
        document.getElementById('mageList23').style.display = "none";
        document.getElementById('asasinList23').style.display = "none";
        document.getElementById('hanterList23').style.display = "none";
        document.getElementById('supportList23').style.display = "none";
    } else if (selectedRadioGroup[2].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList23').style.display = "none";
        document.getElementById('fightList23').style.display = "none";
        document.getElementById('mageList23').style.display = "";
        document.getElementById('asasinList23').style.display = "none";
        document.getElementById('hanterList23').style.display = "none";
        document.getElementById('supportList23').style.display = "none";
    } else if (selectedRadioGroup[3].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList23').style.display = "none";
        document.getElementById('fightList23').style.display = "none";
        document.getElementById('mageList23').style.display = "none";
        document.getElementById('asasinList23').style.display = "";
        document.getElementById('hanterList23').style.display = "none";
        document.getElementById('supportList23').style.display = "none";
    } else if (selectedRadioGroup[4].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList23').style.display = "none";
        document.getElementById('fightList23').style.display = "none";
        document.getElementById('mageList23').style.display = "none";
        document.getElementById('asasinList23').style.display = "none";
        document.getElementById('hanterList23').style.display = "";
        document.getElementById('supportList23').style.display = "none";  
    } else if (selectedRadioGroup[5].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList23').style.display = "none";
        document.getElementById('fightList23').style.display = "none";
        document.getElementById('mageList23').style.display = "none";
        document.getElementById('asasinList23').style.display = "none";
        document.getElementById('hanterList23').style.display = "none";
        document.getElementById('supportList23').style.display = "";  
    
    
    } else {
        document.getElementById('tankList23').style.display = "none";
        document.getElementById('fightList23').style.display = "none";
        document.getElementById('mageList23').style.display = "none";
        document.getElementById('asasinList23').style.display = "none";
        document.getElementById('hanterList23').style.display = "none";
        document.getElementById('supportList23').style.display = "none";  
    }
}

window.addEventListener('load',formSwitch23);


function formSwitch3() {
    const selectedRadioGroup = document.getElementsByName('maker3');
    
    if (selectedRadioGroup[0].checked) {
        // 好きな食べ物が選択されたら下記を実行します
        document.getElementById('tankList3').style.display = "";
        document.getElementById('fightList3').style.display = "none";
        document.getElementById('mageList3').style.display = "none";
        document.getElementById('asasinList3').style.display = "none";
        document.getElementById('hanterList3').style.display = "none";
        document.getElementById('supportList3').style.display = "none";
    } else if (selectedRadioGroup[1].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList3').style.display = "none";
        document.getElementById('fightList3').style.display = "";
        document.getElementById('mageList3').style.display = "none";
        document.getElementById('asasinList3').style.display = "none";
        document.getElementById('hanterList3').style.display = "none";
        document.getElementById('supportList3').style.display = "none";
    } else if (selectedRadioGroup[2].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList3').style.display = "none";
        document.getElementById('fightList3').style.display = "none";
        document.getElementById('mageList3').style.display = "";
        document.getElementById('asasinList3').style.display = "none";
        document.getElementById('hanterList3').style.display = "none";
        document.getElementById('supportList3').style.display = "none";
    } else if (selectedRadioGroup[3].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList3').style.display = "none";
        document.getElementById('fightList3').style.display = "none";
        document.getElementById('mageList3').style.display = "none";
        document.getElementById('asasinList3').style.display = "";
        document.getElementById('hanterList3').style.display = "none";
        document.getElementById('supportList3').style.display = "none";
    } else if (selectedRadioGroup[4].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList3').style.display = "none";
        document.getElementById('fightList3').style.display = "none";
        document.getElementById('mageList3').style.display = "none";
        document.getElementById('asasinList3').style.display = "none";
        document.getElementById('hanterList3').style.display = "";
        document.getElementById('supportList3').style.display = "none";  
    } else if (selectedRadioGroup[5].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList3').style.display = "none";
        document.getElementById('fightList3').style.display = "none";
        document.getElementById('mageList3').style.display = "none";
        document.getElementById('asasinList3').style.display = "none";
        document.getElementById('hanterList3').style.display = "none";
        document.getElementById('supportList3').style.display = "";  
    
    
    } else {
        document.getElementById('tankList3').style.display = "none";
        document.getElementById('fightList3').style.display = "none";
        document.getElementById('mageList3').style.display = "none";
        document.getElementById('asasinList3').style.display = "none";
        document.getElementById('hanterList3').style.display = "none";
        document.getElementById('supportList3').style.display = "none";  
    }
}

window.addEventListener('load',formSwitch3);

function formSwitch33() {
    const selectedRadioGroup = document.getElementsByName('maker33');
    
    if (selectedRadioGroup[0].checked) {
        // 好きな食べ物が選択されたら下記を実行します
        document.getElementById('tankList33').style.display = "";
        document.getElementById('fightList33').style.display = "none";
        document.getElementById('mageList33').style.display = "none";
        document.getElementById('asasinList33').style.display = "none";
        document.getElementById('hanterList33').style.display = "none";
        document.getElementById('supportList33').style.display = "none";
    } else if (selectedRadioGroup[1].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList33').style.display = "none";
        document.getElementById('fightList33').style.display = "";
        document.getElementById('mageList33').style.display = "none";
        document.getElementById('asasinList33').style.display = "none";
        document.getElementById('hanterList33').style.display = "none";
        document.getElementById('supportList33').style.display = "none";
    } else if (selectedRadioGroup[2].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList33').style.display = "none";
        document.getElementById('fightList33').style.display = "none";
        document.getElementById('mageList33').style.display = "";
        document.getElementById('asasinList33').style.display = "none";
        document.getElementById('hanterList33').style.display = "none";
        document.getElementById('supportList33').style.display = "none";
    } else if (selectedRadioGroup[3].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList33').style.display = "none";
        document.getElementById('fightList33').style.display = "none";
        document.getElementById('mageList33').style.display = "none";
        document.getElementById('asasinList33').style.display = "";
        document.getElementById('hanterList33').style.display = "none";
        document.getElementById('supportList33').style.display = "none";
    } else if (selectedRadioGroup[4].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList33').style.display = "none";
        document.getElementById('fightList33').style.display = "none";
        document.getElementById('mageList33').style.display = "none";
        document.getElementById('asasinList33').style.display = "none";
        document.getElementById('hanterList33').style.display = "";
        document.getElementById('supportList33').style.display = "none";  
    } else if (selectedRadioGroup[5].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList33').style.display = "none";
        document.getElementById('fightList33').style.display = "none";
        document.getElementById('mageList33').style.display = "none";
        document.getElementById('asasinList33').style.display = "none";
        document.getElementById('hanterList33').style.display = "none";
        document.getElementById('supportList33').style.display = "";  
    
    
    } else {
        document.getElementById('tankList33').style.display = "none";
        document.getElementById('fightList33').style.display = "none";
        document.getElementById('mageList33').style.display = "none";
        document.getElementById('asasinList33').style.display = "none";
        document.getElementById('hanterList33').style.display = "none";
        document.getElementById('supportList33').style.display = "none";  
    }
}

window.addEventListener('load',formSwitch33);

function formSwitch34() {
    const selectedRadioGroup = document.getElementsByName('maker34');
    
    if (selectedRadioGroup[0].checked) {
        // 好きな食べ物が選択されたら下記を実行します
        document.getElementById('tankList34').style.display = "";
        document.getElementById('fightList34').style.display = "none";
        document.getElementById('mageList34').style.display = "none";
        document.getElementById('asasinList34').style.display = "none";
        document.getElementById('hanterList34').style.display = "none";
        document.getElementById('supportList34').style.display = "none";
    } else if (selectedRadioGroup[1].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList34').style.display = "none";
        document.getElementById('fightList34').style.display = "";
        document.getElementById('mageList34').style.display = "none";
        document.getElementById('asasinList34').style.display = "none";
        document.getElementById('hanterList34').style.display = "none";
        document.getElementById('supportList34').style.display = "none";
    } else if (selectedRadioGroup[2].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList34').style.display = "none";
        document.getElementById('fightList34').style.display = "none";
        document.getElementById('mageList34').style.display = "";
        document.getElementById('asasinList34').style.display = "none";
        document.getElementById('hanterList34').style.display = "none";
        document.getElementById('supportList34').style.display = "none";
    } else if (selectedRadioGroup[3].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList34').style.display = "none";
        document.getElementById('fightList34').style.display = "none";
        document.getElementById('mageList34').style.display = "none";
        document.getElementById('asasinList34').style.display = "";
        document.getElementById('hanterList34').style.display = "none";
        document.getElementById('supportList34').style.display = "none";
    } else if (selectedRadioGroup[4].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList34').style.display = "none";
        document.getElementById('fightList34').style.display = "none";
        document.getElementById('mageList34').style.display = "none";
        document.getElementById('asasinList34').style.display = "none";
        document.getElementById('hanterList34').style.display = "";
        document.getElementById('supportList34').style.display = "none";  
    } else if (selectedRadioGroup[5].checked) {
        // 好きな場所が選択されたら下記を実行します
        document.getElementById('tankList34').style.display = "none";
        document.getElementById('fightList34').style.display = "none";
        document.getElementById('mageList34').style.display = "none";
        document.getElementById('asasinList34').style.display = "none";
        document.getElementById('hanterList34').style.display = "none";
        document.getElementById('supportList34').style.display = "";  
    
    
    } else {
        document.getElementById('tankList34').style.display = "none";
        document.getElementById('fightList34').style.display = "none";
        document.getElementById('mageList34').style.display = "none";
        document.getElementById('asasinList34').style.display = "none";
        document.getElementById('hanterList34').style.display = "none";
        document.getElementById('supportList34').style.display = "none";  
    }
}

window.addEventListener('load',formSwitch34);

